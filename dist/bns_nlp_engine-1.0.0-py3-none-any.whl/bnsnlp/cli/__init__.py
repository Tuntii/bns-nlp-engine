"""
Command-line interface for bns-nlp-engine.

This module provides CLI commands for preprocessing, embedding,
search, and classification operations.
"""

__all__ = []
